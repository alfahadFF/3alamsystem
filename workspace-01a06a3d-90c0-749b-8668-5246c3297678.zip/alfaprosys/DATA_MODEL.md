# نموذج البيانات الحالي — Alfaprosys

مصدر الحقيقة: التطبيق (`DEMO_DATA` في `assets/js/data.js`) وليس جداول قديمة.
عند الربط: املأ `ALFA_CONFIG.supabase` في `config.js` ثم `mode: 'prod'` و `syncEnabled: true`.

التخزين الحالي: IndexedDB `AlfaProSysDB` (مخزن `kv`: `data` + `queue`). الإعدادات الصغيرة (ثيم، مسودة POS، هوية، طابعة) في localStorage. يهاجر تلقائياً من `alfaprosys_data_v1` / `alfaprosys_queue_v1`.

## المجموعات

### categories
`id, name, icon, sort_order, is_active`

### items
`id, category_id, category_name, family, option_name, variant, variant_clean, name, price, barcode?, is_available, sort_order, cost_mode (manual|recipe), cost_manual, order_count, is_pinned_popular, image_url`

### invoices
`id` (يوم إداري + رقم مثل `2026-09-02-001`), `no`, `date`, `type` (dinein/table | takeaway | delivery | contract), `hall`, `table_label`, `customer_name`, `phone`, `cashier`, `status` (open | pending | printed | cancelled), `kitchen_status` (new | cooking | ready | done | delivered), `pay_type` (cash | wallet | partial | deferred), `discount`, `discount_detail`, `total`, `time`, `created_at`, `queue_no`, `stock_applied`, `cancel_reason`, `pending_reason`, `is_online`, `source_order_id`

**items[]:** `id, name, qty, price, total, note, offer_id?, is_free?, offer_disc?`

`status` = الصندوق/التحصيل. `kitchen_status` = المطبخ. لا يُخلطان.

### inventory
`id, name, category, unit, qty, min_qty, cost_per_unit, trackable, loaves_per_bundle?, recipe[], log[]`

**recipe[]:** `item_id, qty` — استهلاك المادة لكل وحدة مباعة من الصنف.

**log[]:** `id, date, type (in|out|waste|adjust), qty, note, auto?, cost?, supplier_id?, supplier_name?, by?`

البيع يخصم عبر `stock.js` (`deductStockForSale`) فقط إذا `invoice.stock_applied === true`.

### customers
`id, name, phone, whatsapp, address, type (regular|contract|vip|delivery), notes, contract_price_list?, credit_limit?, credit_balance?, next_due_date?, payments[]`

### contracts
`id, client_name, company, customer_id, contract_type, start_date, end_date, status, items[], delivery_time, payment_method, installments[], notes, total_value`

### employees
`id, name, age, role, shift, shift_start, shift_end, salary_type, salary_amount, hire_date, phone, notes, salary_log[], deductions_log[]`

### suppliers
`id, name, phone, materials, notes`

### online_orders
`id, created_at, customer {name,phone,address}, items[], subtotal, delivery_fee, discount, total, payment, status (new|done|rejected), source, invoice_id?`

### offers
`id, title, price, active, expires_at, items[{item_id, qty, free?}]`

### discount_settings
`invoice_pct, items[{item_id, pct}]`

### price_settings
`usd_rate, updated_at, last_change`

### cashierSession
`shift_open, cashbox_open, shift_opened_at, cashbox_opened_at, opening_cash, current_cash, cashier_name, last_close?`

### shifts_history
`id, date, cashier, opened_at, closed_at, opening_cash, sales_total, invoices_count, cancelled_count, by_type, by_payment, expenditures, closing_cash, notes, closed_by`

### audit_log
`id, at, module, action, detail, who`

### loyalty / loyalty_ledger
نقاط: `pointsPer1000, rewards[]` — دفتر: `id, customer_id, at, type, pts, note, by`

### delivery_agents
`id, name, type (employee|company), phone, fee_per_trip, notes, is_active`

فاتورة توصيل قد تحمل `delivery_info { agent_id, agent_name, status, fee, assigned_at, delivered_at }`

### tables
حالياً مصفوفة أسماء (`"طاولة 1"`). عند الربط تُحوَّل إلى سجلات `id, label, hall, status`.

## قواعد المزامنة (لاحقاً)
- الفاتورة تُنشأ بمعرّف محلي قبل الخادم (`businessDay + padNo`).
- عمليات المخزون حركات (`in/out`) وليست overwrite.
- الفاتورة بعد `printed` لا تُكتب فوقها: تعديل = حركة عكسية أو تسوية.
- الطابور الحالي: `SyncQueue` يسجّل استبدال المجموعة. سيُوسَّع إلى عملية + حمولة عند تفعيل `syncEnabled`.
