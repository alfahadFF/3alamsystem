/* ============================================================
   sync/remote.js — السحابة شاشة تلو الأخرى
   المنيو: جداول categories + items كما ملأها المستخدم
   (name = الصنف، variant = الحجم)
   ============================================================ */
window.SyncRemote = {
  async flush() {
    const cfg = window.ALFA_CONFIG || {};
    if (!cfg.syncEnabled || !cfg.supabase || !cfg.supabase.url) {
      return { sent: 0, skipped: true, reason: 'sync-disabled' };
    }
    return { sent: 0, skipped: false };
  },
};

window.AlfaCloud = {
  menu: { state: 'idle' },
  customers: { state: 'idle' },
  liveMenu: function () {
    try {
      const id = String(((window.DEMO_DATA && DEMO_DATA.items) || [])[0] && DEMO_DATA.items[0].id || '');
      return /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(id);
    } catch (e) { return false; }
  },
  html: function () {
    const m = this.menu || {};
    const live = this.liveMenu();
    if (m.state === 'ok') {
      return '<div class="cloud-banner cloud-ok">☁ سُحب الآن من السحابة — '
        + (m.cats || 0) + ' تصنيفات · ' + (m.items || 0)
        + ' صنفاً — الربط نجح</div>';
    }
    if (m.state === 'fail' && live) {
      return '<div class="cloud-banner cloud-warn">⚠ تعذر تحديث السحابة الآن — يظهر آخر منيو محفوظ (ليس تجريبياً)'
        + (m.error ? ' · ' + String(m.error).slice(0, 90) : '') + '</div>';
    }
    if (m.state === 'fail' || m.state === 'offline' || m.state === 'empty') {
      const why = m.error ? ' · ' + String(m.error).slice(0, 90) : '';
      return '<div class="cloud-banner cloud-fail">⚠ تعذر الربط بالسحابة — المنيو فارغ حتى ينجح السحب' + why + '</div>';
    }
    return '';
  },
};

window.AlfaSB = (function () {
  function cfg() { return (window.ALFA_CONFIG && ALFA_CONFIG.supabase) || {}; }
  function enabled() { const s = cfg(); return !!(s.url && s.anonKey); }
  function useProxy() {
    try {
      if (location.protocol === 'file:') return false;
      return /e2b\.app$/i.test(String(location.hostname || ''));
    } catch (e) { return false; }
  }
  function root() {
    if (useProxy()) return '';
    return String(cfg().url || '').replace(/\/$/, '');
  }
  function headers(prefer) {
    const s = cfg();
    const h = {
      apikey: s.anonKey,
      Authorization: 'Bearer ' + s.anonKey,
      Accept: 'application/json',
      'Content-Type': 'application/json',
    };
    if (prefer) h.Prefer = prefer;
    return h;
  }
  function rest(table, qs) { return root() + '/rest/v1/' + table + (qs || ''); }
  function get(table, qs) {
    return fetch(rest(table, qs || '?select=*'), { headers: headers() }).then(function (res) {
      return res.text().then(function (t) {
        if (!res.ok) throw new Error(table + ' ' + res.status + ' ' + t.slice(0, 180));
        return t ? JSON.parse(t) : [];
      });
    });
  }
  function upsert(table, rows, conflict) {
    if (!rows.length) return Promise.resolve();
    return fetch(rest(table, '?on_conflict=' + conflict), {
      method: 'POST',
      headers: headers('resolution=merge-duplicates,return=minimal'),
      body: JSON.stringify(rows),
    }).then(function (res) {
      return res.text().then(function (t) {
        if (!res.ok) throw new Error(table + ' upsert ' + res.status + ' ' + t.slice(0, 220));
      });
    });
  }
  function del(table, ids) {
    if (!ids.length) return Promise.resolve();
    const list = ids.map(function (id) { return '"' + String(id).replace(/"/g, '') + '"'; }).join(',');
    return fetch(rest(table, '?id=in.(' + list + ')'), {
      method: 'DELETE',
      headers: headers('return=minimal'),
    }).then(function (res) {
      if (!res.ok) return res.text().then(function (t) { throw new Error(table + ' delete ' + t.slice(0, 180)); });
    });
  }
  function delFilter(table, qs) {
    return fetch(rest(table, qs || ''), {
      method: 'DELETE',
      headers: headers('return=minimal'),
    }).then(function (res) {
      if (!res.ok) return res.text().then(function (t) { throw new Error(table + ' delete ' + t.slice(0, 180)); });
    });
  }
  function insert(table, rows) {
    if (!rows.length) return Promise.resolve();
    return fetch(rest(table, ''), {
      method: 'POST',
      headers: headers('return=minimal'),
      body: JSON.stringify(rows),
    }).then(function (res) {
      return res.text().then(function (t) {
        if (!res.ok) throw new Error(table + ' insert ' + res.status + ' ' + t.slice(0, 220));
      });
    });
  }
  return { enabled: enabled, get: get, upsert: upsert, del: del, delFilter: delFilter, insert: insert };
})();

window.MenuSync = (function () {
  const sb = window.AlfaSB;
  let pushTimer = null;
  const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
  function isUuid(id) { return UUID.test(String(id || '')); }

  function fromRemote(i, cats) {
    const cid = i.category_id != null ? String(i.category_id) : '';
    const cat = (cats || []).find(function (c) { return String(c.id) === cid; });
    const base = String(i.name || '').trim();
    const variant = String(i.variant || '').trim();
    return {
      id: String(i.id),
      category_id: cid,
      category_name: cat ? cat.name : '',
      family: base,
      option_name: base,
      variant: variant || null,
      variant_clean: variant || null,
      name: variant ? (base + ' ' + variant) : base,
      price: Math.round(Number(i.price) || 0),
      cost_mode: i.cost_mode || 'manual',
      cost_manual: Math.round(Number(i.cost_manual) || 0),
      is_available: i.is_available !== false,
      sort_order: Number(i.sort_order) || 0,
      order_count: Number(i.order_count) || 0,
      is_pinned_popular: !!i.is_pinned_popular,
      image_url: i.image_url || null,
      price_new: i.price_new,
      price_usd: i.price_usd,
      discount_pct: i.discount_pct,
    };
  }

  function toRemote(it) {
    if (!isUuid(it.id) || !isUuid(it.category_id)) return null;
    const family = String(it.family || it.option_name || '').trim();
    const variant = String(it.variant || it.variant_clean || '').trim();
    return {
      id: it.id,
      category_id: it.category_id,
      name: family || it.name || '',
      variant: variant || null,
      price: Math.round(Number(it.price) || 0),
      cost_mode: it.cost_mode || 'manual',
      cost_manual: Math.round(Number(it.cost_manual) || 0),
      is_available: it.is_available !== false,
      sort_order: Number(it.sort_order) || 0,
      order_count: Number(it.order_count) || 0,
      is_pinned_popular: !!it.is_pinned_popular,
      image_url: it.image_url || null,
    };
  }

  function pull() {
    if (!sb.enabled()) {
      window.AlfaCloud.menu = { state: 'fail', error: 'لا مفاتيح سحابة' };
      return Promise.resolve({ skipped: true });
    }
    if (navigator.onLine === false) {
      window.AlfaCloud.menu = { state: 'offline', error: 'بدون إنترنت' };
      return Promise.resolve({ skipped: true });
    }
    return Promise.all([
      sb.get('categories', '?select=id,name,icon,sort_order,is_active&order=sort_order.asc'),
      sb.get('items', '?select=id,category_id,name,price,cost_mode,cost_manual,is_available,sort_order,order_count,is_pinned_popular,image_url,variant,price_new,price_usd,discount_pct&order=sort_order.asc'),
    ]).then(function (pair) {
      const cats = pair[0] || [];
      const remote = pair[1] || [];
      if (!remote.length) {
        window.AlfaCloud.menu = { state: 'empty', error: 'جدول الأصناف فارغ' };
        return { skipped: true, reason: 'empty' };
      }
      const items = remote.map(function (i) { return fromRemote(i, cats); });
      if (window.DEMO_DATA) {
        DEMO_DATA.categories = cats;
        DEMO_DATA.items = items;
        /* لا تُعرض عروض/خصومات الملف التجريبي مع المنيو الحقيقي */
        DEMO_DATA.offers = [];
        DEMO_DATA.discount_settings = { invoice_pct: 0, items: [] };
      }
      window.AlfaCloud.menu = { state: 'ok', items: items.length, cats: cats.length, at: Date.now() };
      try { if (window.alfaPersist) window.alfaPersist(); } catch (e) {}
      return { pulled: true, items: items.length, cats: cats.length };
    }).catch(function (e) {
      window.AlfaCloud.menu = { state: 'fail', error: String(e && e.message || e) };
      return { skipped: true, error: String(e && e.message || e) };
    });
  }

  function push() {
    if (!sb.enabled() || navigator.onLine === false) return Promise.resolve({ skipped: true });
    const d = window.DEMO_DATA || {};
    const items = (d.items || []).map(toRemote).filter(Boolean);
    if (!items.length) return Promise.resolve({ skipped: true, reason: 'no-uuid' });
    const cats = (d.categories || []).map(function (c) {
      return {
        id: String(c.id), name: c.name || '', icon: c.icon || '🏷️',
        sort_order: Number(c.sort_order) || 0, is_active: c.is_active !== false,
      };
    });
    return sb.upsert('categories', cats, 'id')
      .then(function () { return sb.upsert('items', items, 'id'); })
      .then(function () { return { pushed: true, items: items.length }; });
  }

  function pushSoon() {
    if (!sb.enabled()) return;
    clearTimeout(pushTimer);
    pushTimer = setTimeout(function () {
      push().catch(function (e) {
        try { if (window.showToast) showToast('تعذر رفع المنيو: ' + (e && e.message || e), '⚠️'); } catch (err) {}
      });
    }, 700);
  }

  return {
    enabled: sb.enabled, pull: pull, push: push, pushSoon: pushSoon,
    removeItem: function (id) { return (!sb.enabled() || !id) ? Promise.resolve() : sb.del('items', [id]).catch(function () {}); },
    removeCat: function (id) { return (!sb.enabled() || !id) ? Promise.resolve() : sb.del('categories', [id]).catch(function () {}); },
  };
})();

window.CustomerSync = (function () {
  const sb = window.AlfaSB;
  let pushTimer = null;

  function row(c) {
    const due = c.next_due_date ? String(c.next_due_date) : null;
    return {
      id: String(c.id),
      name: c.name || '',
      phone: c.phone || null,
      whatsapp: c.whatsapp || null,
      address: c.address || null,
      type: c.type || 'regular',
      notes: c.notes || null,
      contract_price_list: c.contract_price_list || null,
      credit_limit: Number(c.credit_limit) || 0,
      credit_balance: Number(c.credit_balance) || 0,
      next_due_date: due || null,
      payments: Array.isArray(c.payments) ? c.payments : [],
      source: c.source || 'pos',
    };
  }

  function pull() {
    if (!sb.enabled() || navigator.onLine === false) return Promise.resolve({ skipped: true });
    const local = (window.DEMO_DATA && DEMO_DATA.customers) || [];
    return sb.get('customers', '?select=*&order=name.asc').then(function (remote) {
      if (!(remote || []).length) {
        return push().then(function () {
          window.AlfaCloud.customers = { state: 'ok', n: local.length, seeded: true };
          return { seeded: true, n: local.length };
        });
      }
      if (window.DEMO_DATA) DEMO_DATA.customers = remote;
      window.AlfaCloud.customers = { state: 'ok', n: remote.length };
      return { pulled: true, n: remote.length };
    }).catch(function (e) {
      window.AlfaCloud.customers = { state: 'fail', error: String(e && e.message || e) };
      return { skipped: true };
    });
  }

  function push() {
    if (!sb.enabled() || navigator.onLine === false) return Promise.resolve({ skipped: true });
    const list = ((window.DEMO_DATA && DEMO_DATA.customers) || []).map(row);
    return sb.get('customers', '?select=id').then(function (remote) {
      const localIds = {};
      list.forEach(function (c) { localIds[c.id] = true; });
      const extra = (remote || []).map(function (r) { return r.id; }).filter(function (id) { return !localIds[id]; });
      return sb.upsert('customers', list, 'id')
        .then(function () { return sb.del('customers', extra); })
        .then(function () { return { pushed: true, n: list.length }; });
    });
  }

  function pushSoon() {
    if (!sb.enabled()) return;
    clearTimeout(pushTimer);
    pushTimer = setTimeout(function () {
      push().catch(function (e) {
        try { if (window.showToast) showToast('تعذر رفع العملاء: ' + (e && e.message || e), '⚠️'); } catch (err) {}
      });
    }, 700);
  }

  return {
    enabled: sb.enabled, pull: pull, push: push, pushSoon: pushSoon,
    remove: function (id) { return (!sb.enabled() || !id) ? Promise.resolve() : sb.del('customers', [id]).catch(function () {}); },
  };
})();

window.InvoiceSync = (function () {
  const sb = window.AlfaSB;
  const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
  function isUuid(id) { return UUID.test(String(id || '')); }

  function fromLine(l) {
    return {
      id: l.item_id || ('line_' + l.id),
      line_id: l.id,
      name: l.name || '',
      qty: Number(l.qty) || 0,
      price: Math.round(Number(l.price) || 0),
      total: Math.round(Number(l.total) || 0),
      note: l.note || '',
      offer_id: l.offer_id || null,
      is_free: !!l.is_free,
      offer_disc: !!l.offer_disc,
    };
  }

  function fromInv(row, lines) {
    return {
      id: String(row.id),
      no: Number(row.no) || 0,
      date: row.date || '',
      type: row.type || 'takeaway',
      hall: row.hall || '',
      table_label: row.table_label || '',
      customer_name: row.customer_name || '',
      phone: row.phone || '',
      cashier: row.cashier || '',
      status: row.status || 'open',
      kitchen_status: row.kitchen_status || 'new',
      pay_type: row.pay_type || null,
      contract_id: row.contract_id || null,
      online_order_id: row.online_order_id || null,
      discount: Number(row.discount) || 0,
      discount_detail: row.discount_detail || null,
      total: Number(row.total) || 0,
      time: row.time || '',
      queue_no: row.queue_no,
      cancel_reason: row.cancel_reason || null,
      pending_reason: row.pending_reason || null,
      is_online: !!row.is_online,
      is_new_customer: !!row.is_new_customer,
      created_at: row.created_at,
      items: (lines || []).map(fromLine),
    };
  }

  function toInv(inv) {
    return {
      id: String(inv.id),
      no: Number(inv.no) || 0,
      date: inv.date || '',
      type: inv.type || 'takeaway',
      hall: inv.hall || null,
      table_label: inv.table_label || null,
      customer_name: inv.customer_name || null,
      phone: inv.phone || null,
      cashier: inv.cashier || null,
      status: inv.status || 'open',
      kitchen_status: inv.kitchen_status || 'new',
      pay_type: inv.pay_type || 'cash',
      contract_id: inv.contract_id || null,
      online_order_id: inv.online_order_id || inv.source_order_id || null,
      discount: Number(inv.discount) || 0,
      discount_detail: inv.discount_detail || null,
      total: Number(inv.total) || 0,
      time: inv.time || null,
      queue_no: inv.queue_no == null ? null : inv.queue_no,
      cancel_reason: inv.cancel_reason || null,
      pending_reason: inv.pending_reason || null,
      is_online: !!inv.is_online,
      is_new_customer: !!inv.is_new_customer,
    };
  }

  function toLine(invId, c) {
    const iid = c.offer_disc ? null : (isUuid(c.id) ? c.id : null);
    return {
      invoice_id: invId,
      item_id: iid,
      name: c.name || '',
      qty: Number(c.qty) || 0,
      price: Math.round(Number(c.price) || 0),
      total: Math.round((Number(c.price) || 0) * (Number(c.qty) || 0)),
      note: c.note || null,
      offer_id: c.offer_id || null,
      is_free: !!c.is_free,
      offer_disc: !!c.offer_disc,
    };
  }

  function pull() {
    if (!sb.enabled() || navigator.onLine === false) return Promise.resolve({ skipped: true });
    return Promise.all([
      sb.get('invoices', '?select=*&order=created_at.desc'),
      sb.get('invoice_items', '?select=*'),
    ]).then(function (pair) {
      const rows = pair[0] || [];
      const lines = pair[1] || [];
      const by = {};
      lines.forEach(function (l) {
        const k = String(l.invoice_id);
        (by[k] || (by[k] = [])).push(l);
      });
      const invoices = rows.map(function (r) { return fromInv(r, by[String(r.id)] || []); });
      if (window.DEMO_DATA) DEMO_DATA.invoices = invoices;
      return { pulled: true, n: invoices.length };
    }).catch(function (e) {
      return { skipped: true, error: String(e && e.message || e) };
    });
  }

  function pushOne(inv) {
    if (!sb.enabled() || !inv || !inv.id) return Promise.resolve({ skipped: true });
    const row = toInv(inv);
    const lines = (inv.items || []).map(function (c) { return toLine(row.id, c); });
    return sb.upsert('invoices', [row], 'id')
      .then(function () { return sb.delFilter('invoice_items', '?invoice_id=eq.' + encodeURIComponent(row.id)); })
      .then(function () { return sb.insert('invoice_items', lines); })
      .then(function () { return { pushed: true, id: row.id }; });
  }

  function remove(id) {
    if (!sb.enabled() || !id) return Promise.resolve();
    return sb.delFilter('invoice_items', '?invoice_id=eq.' + encodeURIComponent(id))
      .then(function () { return sb.del('invoices', [id]); })
      .catch(function (e) {
        try { if (window.showToast) showToast('تعذر حذف الفاتورة من السحابة: ' + (e && e.message || e), '⚠️'); } catch (err) {}
      });
  }

  function pushSoon(inv) {
    if (!sb.enabled() || !inv) return;
    pushOne(inv).catch(function (e) {
      try { if (window.showToast) showToast('تعذر رفع الفاتورة: ' + (e && e.message || e), '⚠️'); } catch (err) {}
    });
  }

  return { pull: pull, pushOne: pushOne, pushSoon: pushSoon, remove: remove };
})();

window.PosSync = (function () {
  const sb = window.AlfaSB;

  function pullOffers() {
    return Promise.all([
      sb.get('offers', '?select=id,title,price,active,expires_at'),
      sb.get('offer_items', '?select=*').catch(function () { return []; }),
    ]).then(function (pair) {
      const offers = pair[0] || [];
      const lines = pair[1] || [];
      const by = {};
      lines.forEach(function (l) {
        const k = String(l.offer_id);
        (by[k] || (by[k] = [])).push({ item_id: l.item_id, qty: Number(l.qty) || 1, free: !!l.free });
      });
      return offers.map(function (o) {
        return {
          id: String(o.id),
          title: o.title || '',
          price: Math.round(Number(o.price) || 0),
          active: o.active !== false,
          expires_at: o.expires_at || null,
          items: by[String(o.id)] || [],
        };
      });
    });
  }

  function pull() {
    if (!sb.enabled() || navigator.onLine === false) return Promise.resolve({ skipped: true });
    return Promise.all([
      pullOffers().catch(function () { return []; }),
      sb.get('contracts', '?select=*').catch(function () { return []; }),
      sb.get('online_orders', '?select=*').catch(function () { return []; }),
      sb.get('settings', '?select=key,value&key=eq.discount').catch(function () { return []; }),
    ]).then(function (pack) {
      const offers = pack[0] || [];
      const contracts = pack[1] || [];
      const online = pack[2] || [];
      const discRows = pack[3] || [];
      if (window.DEMO_DATA) {
        DEMO_DATA.offers = offers;
        DEMO_DATA.contracts = contracts;
        DEMO_DATA.online_orders = online;
        const disc = (discRows[0] && discRows[0].value) || { invoice_pct: 0, items: [] };
        const liveIds = {};
        (DEMO_DATA.items || []).forEach(function (i) { liveIds[String(i.id)] = true; });
        DEMO_DATA.discount_settings = {
          invoice_pct: Number(disc.invoice_pct) || 0,
          items: (disc.items || []).filter(function (r) { return liveIds[String(r.item_id)]; }),
        };
      }
      return { pulled: true, offers: offers.length, contracts: contracts.length, online: online.length };
    }).catch(function (e) {
      return { skipped: true, error: String(e && e.message || e) };
    });
  }

  return { pull: pull };
})();
